@echo off
title   OTIMIZACAO WINDOWS 11 - VERSAO CORPORATIVA
color 0A
setlocal EnableDelayedExpansion

:: =====================================================
::  OTIMIZACAO WINDOWS 11 - VERSAO CORPORATIVA
::  Versao: W11 24H2
::  Perfil: Ambiente de trabalho / acesso remoto (AnyDesk)
::
::  O QUE FOI REMOVIDO vs versao gaming:
::    [X] Etapa de rede (Nagle/ECN/AutoTuning) - preserva AnyDesk
::    [X] Desativacao de VBS/Memory Integrity   - seguranca corporativa
::    [X] Desativacao de Spectre/Meltdown       - vulnerabilidade critica
::    [X] Remocao do Microsoft Teams            - ferramenta corporativa
::    [X] Desativacao do WSearch                - Outlook depende disso
::    [X] Desativacao do RemoteRegistry         - gestao remota de TI
::    [X] Desativacao do WerSvc                 - monitoramento de TI
::    [X] Desativacao de Notificacoes           - foco no trabalho
::    [X] Tarefas automaticas                   - Reboot diario as 02:00 e limpeza no logon
::
::  SEGURO PARA: AnyDesk, dominio corporativo, Outlook,
::               gestao remota, politicas de seguranca
:: =====================================================

:: --- Verificar se esta rodando como Administrador ---
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo ============================================
    echo  ERRO: Execute este script como ADMINISTRADOR!
    echo  Clique com botao direito ^> Executar como Administrador
    echo ============================================
    pause
    exit /b 1
)

cls
echo =====================================================
echo   OTIMIZACAO WINDOWS 11 - VERSAO CORPORATIVA
echo =====================================================
echo.
echo   Perfil: PC de trabalho com acesso remoto (AnyDesk)
echo   Windows 11 24H2
echo.
echo   Este script ira:
echo     [1] Desativar servicos verdadeiramente desnecessarios
echo     [2] Aplicar tweaks de registro (GPU/CPU/GameDVR)
echo     [3] REDE: NAO SERA ALTERADA (preserva AnyDesk)
echo     [4] Ativar plano de energia Ultimate Performance
echo     [5] Desativar tarefas agendadas de telemetria
echo     [6] Desativar efeitos visuais do Windows 11
echo     [7] Limpar lixo do sistema (inclui Delivery Optimization)
echo     [8] Desativar Hibernate
echo     [9] Remover bloatware (preserva Teams e ferramentas corp.)
echo     [10] Criar tarefas: Reboot 02:00AM e Limpeza no Logon
echo.
echo   NAO ALTERADO (seguranca/corporativo):
echo     [=] Rede TCP/IP    - preserva conexao AnyDesk
echo     [=] VBS/HVCI       - seguranca corporativa
echo     [=] Spectre/Meltdown mitigations - vulnerabilidade critica
echo     [=] RemoteRegistry - gestao remota de TI
echo     [=] WSearch        - necessario para Outlook
echo     [=] WerSvc         - monitoramento corporativo
echo     [=] Microsoft Teams - ferramenta corporativa
echo.
echo   Para reverter, use: reverter_win11.bat
echo =====================================================
echo.
set /p CONFIRMA="Deseja prosseguir? (S/N): "
if /i not "%CONFIRMA%"=="S" (
    echo Operacao cancelada pelo usuario.
    pause
    exit /b 0
)

:: --- Criar log ---
set "LOGFILE=%~dp0otimizar_win11_empresa_log.txt"
echo ===================================================== > "%LOGFILE%"
echo  LOG DE OTIMIZACAO CORPORATIVA - WINDOWS 11 24H2 >> "%LOGFILE%"
echo  Data/Hora: %date% %time% >> "%LOGFILE%"
echo ===================================================== >> "%LOGFILE%"
echo. >> "%LOGFILE%"

:: =====================================================
:: ETAPA 1 - DESATIVAR SERVICOS DESNECESSARIOS
:: =====================================================
echo.
echo [1/9] Desativando servicos desnecessarios...
echo. >> "%LOGFILE%"
echo [1/9] Servicos desativados: >> "%LOGFILE%"

:: Telemetria e Coleta de Dados
sc stop DiagTrack >nul 2>&1
sc config DiagTrack start=disabled >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v AllowTelemetry /t REG_DWORD /d 0 /f >nul 2>&1
echo       [-] DiagTrack e AllowTelemetry (Telemetria)
echo       DiagTrack e AllowTelemetry >> "%LOGFILE%"

:: Diagnostic Data Service
sc stop DiagnosticDataService >nul 2>&1
sc config DiagnosticDataService start=disabled >nul 2>&1
echo       [-] DiagnosticDataService (Dados Diagnosticos)
echo       DiagnosticDataService >> "%LOGFILE%"

:: Superfetch / SysMain
:: NOTA: Seguro desativar em SSDs. Em HDDs pode reduzir performance.
sc stop SysMain >nul 2>&1
sc config SysMain start=disabled >nul 2>&1
echo       [-] SysMain (Superfetch) - recomendado apenas em SSD
echo       SysMain >> "%LOGFILE%"

:: Mapas Offline
sc stop MapsBroker >nul 2>&1
sc config MapsBroker start=disabled >nul 2>&1
echo       [-] MapsBroker (Mapas Offline)
echo       MapsBroker >> "%LOGFILE%"

:: Fax
sc stop Fax >nul 2>&1
sc config Fax start=disabled >nul 2>&1
echo       [-] Fax
echo       Fax >> "%LOGFILE%"

:: Retail Demo
sc stop RetailDemo >nul 2>&1
sc config RetailDemo start=disabled >nul 2>&1
echo       [-] RetailDemo (Modo Demo)
echo       RetailDemo >> "%LOGFILE%"

:: Windows Media Player Network
sc stop WMPNetworkSvc >nul 2>&1
sc config WMPNetworkSvc start=disabled >nul 2>&1
echo       [-] WMPNetworkSvc (WMP Rede)
echo       WMPNetworkSvc >> "%LOGFILE%"

:: Geolocalizacao
sc stop lfsvc >nul 2>&1
sc config lfsvc start=disabled >nul 2>&1
echo       [-] lfsvc (Geolocalizacao)
echo       lfsvc >> "%LOGFILE%"

:: AllJoyn Router (IoT, nao usado em corporativo)
sc stop AJRouter >nul 2>&1
sc config AJRouter start=disabled >nul 2>&1
echo       [-] AJRouter (AllJoyn IoT)
echo       AJRouter >> "%LOGFILE%"

:: Windows Insider
sc stop wisvc >nul 2>&1
sc config wisvc start=disabled >nul 2>&1
echo       [-] wisvc (Windows Insider)
echo       wisvc >> "%LOGFILE%"

:: Hotspot Movel
sc stop icssvc >nul 2>&1
sc config icssvc start=disabled >nul 2>&1
echo       [-] icssvc (Hotspot Movel)
echo       icssvc >> "%LOGFILE%"

:: Controle dos Pais
sc stop WpcMonSvc >nul 2>&1
sc config WpcMonSvc start=disabled >nul 2>&1
echo       [-] WpcMonSvc (Controle dos Pais)
echo       WpcMonSvc >> "%LOGFILE%"

:: Pagamentos NFC
sc stop SEMgrSvc >nul 2>&1
sc config SEMgrSvc start=disabled >nul 2>&1
echo       [-] SEMgrSvc (NFC/Pagamentos)
echo       SEMgrSvc >> "%LOGFILE%"

:: Phone Service
sc stop PhoneSvc >nul 2>&1
sc config PhoneSvc start=disabled >nul 2>&1
echo       [-] PhoneSvc (Servico Telefone)
echo       PhoneSvc >> "%LOGFILE%"

:: Distributed Link Tracking
sc stop TrkWks >nul 2>&1
sc config TrkWks start=disabled >nul 2>&1
echo       [-] TrkWks (Link Tracking)
echo       TrkWks >> "%LOGFILE%"

:: --- MANTIDOS INTENCIONALMENTE ---
:: WSearch      - Outlook usa indexacao de emails
:: RemoteRegistry - TI pode precisar de acesso remoto ao registro
:: WerSvc       - Relatorio de erros (monitoramento corporativo)

echo       [=] WSearch, RemoteRegistry e WerSvc MANTIDOS (corporativo)
echo       WSearch/RemoteRegistry/WerSvc mantidos (corporativo) >> "%LOGFILE%"
echo       Servicos concluidos!

:: =====================================================
:: ETAPA 2 - TWEAKS DE REGISTRO (PERFORMANCE)
:: =====================================================
echo.
echo [2/9] Aplicando tweaks de registro...
echo. >> "%LOGFILE%"
echo [2/9] Tweaks de registro: >> "%LOGFILE%"

:: Desativar Game DVR
reg add "HKCU\System\GameConfigStore" /v GameDVR_Enabled /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\System\GameConfigStore" /v GameDVR_FSEBehaviorMode /t REG_DWORD /d 2 /f >nul 2>&1
reg add "HKCU\System\GameConfigStore" /v GameDVR_DXGIHonorFSEWindowsCompatible /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\System\GameConfigStore" /v GameDVR_FSEBehavior /t REG_DWORD /d 2 /f >nul 2>&1
reg add "HKCU\System\GameConfigStore" /v GameDVR_HonorUserFSEBehaviorMode /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR" /v AllowGameDVR /t REG_DWORD /d 0 /f >nul 2>&1
echo       [-] Game DVR desativado
echo       Game DVR >> "%LOGFILE%"

:: Desativar apps em segundo plano
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v GlobalUserDisabled /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v BackgroundAppGlobalToggle /t REG_DWORD /d 0 /f >nul 2>&1
echo       [-] Apps em segundo plano desativados
echo       Background Apps >> "%LOGFILE%"

:: Desativar Cortana
:: NOTA: Copilot NAO desativado - pode ser ferramenta corporativa licenciada
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v AllowCortana /t REG_DWORD /d 0 /f >nul 2>&1
echo       [-] Cortana desativada (Copilot mantido - verificar licenca)
echo       Cortana >> "%LOGFILE%"

:: Desativar dicas, sugestoes, ads e tela "Terminar configuracao" (Scoobe)
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement" /v ScoobeSystemSettingEnabled /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SubscribedContent-338389Enabled /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SubscribedContent-310093Enabled /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SubscribedContent-338388Enabled /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SubscribedContent-338393Enabled /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SoftLandingEnabled /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v RotatingLockScreenEnabled /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v RotatingLockScreenOverlayEnabled /t REG_DWORD /d 0 /f >nul 2>&1
echo       [-] Tela de Config (Lembrar em 3 dias) e dicas desativadas
echo       Dicas/Ads/Scoobe >> "%LOGFILE%"

:: Desativar Power Throttling
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" /v PowerThrottlingOff /t REG_DWORD /d 1 /f >nul 2>&1
echo       [-] Power Throttling desativado
echo       Power Throttling >> "%LOGFILE%"

:: Desativar Notificacoes e Central de Acoes
reg add "HKCU\Software\Policies\Microsoft\Windows\Explorer" /v DisableNotificationCenter /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\PushNotifications" /v ToastEnabled /t REG_DWORD /d 0 /f >nul 2>&1
echo       [-] Notificacoes e Central de Acoes desativados
echo       Notificacoes >> "%LOGFILE%"

:: Desativar Prefetch/Superfetch via registro
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters" /v EnablePrefetcher /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters" /v EnableSuperfetch /t REG_DWORD /d 0 /f >nul 2>&1
echo       [-] Prefetch/Superfetch desativados via registro
echo       Prefetch/Superfetch >> "%LOGFILE%"

:: Prioridade de CPU para aplicacoes em primeiro plano
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v SystemResponsiveness /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v NetworkThrottlingIndex /t REG_DWORD /d 0xffffffff /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "GPU Priority" /t REG_DWORD /d 8 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v Priority /t REG_DWORD /d 6 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Scheduling Category" /t REG_SZ /d "High" /f >nul 2>&1
echo       [-] Prioridade GPU/CPU configurada
echo       GPU/CPU Priority >> "%LOGFILE%"

:: --- NAO APLICADO: VBS/HVCI - seguranca corporativa ---
:: --- NAO APLICADO: Spectre/Meltdown - vulnerabilidade critica ---
echo       [=] VBS/HVCI e Spectre/Meltdown MANTIDOS (seguranca)
echo       VBS e Spectre/Meltdown mantidos (seguranca corporativa) >> "%LOGFILE%"

echo       Tweaks de registro aplicados!

:: =====================================================
:: ETAPA 3 - REDE: NAO ALTERADA
:: =====================================================
echo.
echo [3/9] Rede: ETAPA IGNORADA intencionalmente...
echo. >> "%LOGFILE%"
echo [3/9] Rede nao alterada - preserva AnyDesk e conectividade >> "%LOGFILE%"
echo       [=] TCP/IP, Nagle, ECN, Auto-Tuning: SEM ALTERACOES
echo       [=] Conexao AnyDesk preservada
echo       Flush de DNS apenas (seguro):
ipconfig /flushdns >nul 2>&1
echo       [-] Cache DNS limpo (unica operacao de rede segura)
echo       DNS flush >> "%LOGFILE%"

:: =====================================================
:: ETAPA 4 - PLANO DE ENERGIA ULTIMATE PERFORMANCE
:: =====================================================
echo.
echo [4/9] Configurando plano de energia...
echo. >> "%LOGFILE%"
echo [4/9] Plano de energia: >> "%LOGFILE%"

powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 >nul 2>&1
powercfg -setactive e9a42b02-d5df-448d-aa00-03f14749eb61 >nul 2>&1
if %errorlevel% neq 0 (
    powercfg -setactive SCHEME_MIN >nul 2>&1
    echo       [-] Plano "Alto Desempenho" ativado (Ultimate nao disponivel)
    echo       Alto Desempenho ativado >> "%LOGFILE%"
) else (
    echo       [-] Plano "Ultimate Performance" ativado!
    echo       Ultimate Performance ativado >> "%LOGFILE%"
)

:: Timer resolution
bcdedit /set useplatformtick yes >nul 2>&1
bcdedit /set disabledynamictick yes >nul 2>&1
echo       [-] Timer Resolution otimizado
echo       Timer bcdedit >> "%LOGFILE%"

echo       Plano de energia configurado!

:: =====================================================
:: ETAPA 5 - TAREFAS AGENDADAS DE TELEMETRIA
:: =====================================================
echo.
echo [5/9] Desativando tarefas agendadas de telemetria...
echo. >> "%LOGFILE%"
echo [5/9] Tarefas agendadas desativadas: >> "%LOGFILE%"

schtasks /Change /TN "\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser" /Disable >nul 2>&1
echo       [-] Compatibility Appraiser
echo       Compatibility Appraiser >> "%LOGFILE%"

schtasks /Change /TN "\Microsoft\Windows\Application Experience\ProgramDataUpdater" /Disable >nul 2>&1
echo       [-] ProgramDataUpdater
echo       ProgramDataUpdater >> "%LOGFILE%"

schtasks /Change /TN "\Microsoft\Windows\Customer Experience Improvement Program\Consolidator" /Disable >nul 2>&1
echo       [-] CEIP Consolidator
echo       CEIP Consolidator >> "%LOGFILE%"

schtasks /Change /TN "\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip" /Disable >nul 2>&1
echo       [-] UsbCeip
echo       UsbCeip >> "%LOGFILE%"

schtasks /Change /TN "\Microsoft\Windows\Autochk\Proxy" /Disable >nul 2>&1
echo       [-] Autochk Proxy
echo       Autochk Proxy >> "%LOGFILE%"

schtasks /Change /TN "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector" /Disable >nul 2>&1
echo       [-] DiskDiagnosticDataCollector
echo       DiskDiagnosticDataCollector >> "%LOGFILE%"

schtasks /Change /TN "\Microsoft\Windows\Flighting\FeatureConfig\ReconcileFeatures" /Disable >nul 2>&1
echo       [-] ReconcileFeatures (Flighting)
echo       ReconcileFeatures >> "%LOGFILE%"

schtasks /Change /TN "\Microsoft\Windows\Flighting\OneSettings\RefreshCache" /Disable >nul 2>&1
echo       [-] RefreshCache (OneSettings)
echo       RefreshCache >> "%LOGFILE%"

:: QueueReporting mantido - TI pode usar para monitoramento de erros
echo       [=] QueueReporting MANTIDO (monitoramento de TI)
echo       QueueReporting mantido (corporativo) >> "%LOGFILE%"

echo       Tarefas agendadas desativadas!

:: =====================================================
:: ETAPA 6 - EFEITOS VISUAIS
:: =====================================================
echo.
echo [6/9] Desativando efeitos visuais do Windows 11...
echo. >> "%LOGFILE%"
echo [6/9] Efeitos visuais: >> "%LOGFILE%"

:: Desativar transparencia
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v EnableTransparency /t REG_DWORD /d 0 /f >nul 2>&1
echo       [-] Transparencia desativada
echo       Transparencia >> "%LOGFILE%"

:: Animacoes e performance customizadas
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" /v VisualFXSetting /t REG_DWORD /d 3 /f >nul 2>&1
reg add "HKCU\Control Panel\Desktop" /v UserPreferencesMask /t REG_BINARY /d 9012038010000000 /f >nul 2>&1
reg add "HKCU\Control Panel\Desktop\WindowMetrics" /v MinAnimate /t REG_SZ /d 0 /f >nul 2>&1
reg add "HKCU\Control Panel\Desktop" /v MenuShowDelay /t REG_SZ /d 0 /f >nul 2>&1
:: 1. Mostrar conteudo da janela ao arrastar
reg add "HKCU\Control Panel\Desktop" /v DragFullWindows /t REG_SZ /d 1 /f >nul 2>&1
:: 2. Usar fontes de tela com cantos arredondados
reg add "HKCU\Control Panel\Desktop" /v FontSmoothing /t REG_SZ /d 2 /f >nul 2>&1
reg add "HKCU\Control Panel\Desktop" /v FontSmoothingType /t REG_DWORD /d 2 /f >nul 2>&1
:: 3. Mostrar miniaturas em vez de icones
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v IconsOnly /t REG_DWORD /d 0 /f >nul 2>&1
echo       [-] Sombras e animacoes inuteis desativadas (Arrastar, Miniaturas e Fonte suave preservados)
echo       Animacoes/Sombras >> "%LOGFILE%"

:: Desativar Widgets
reg add "HKLM\SOFTWARE\Policies\Microsoft\Dsh" /v AllowNewsAndInterests /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarDa /t REG_DWORD /d 0 /f >nul 2>&1
echo       [-] Widgets desativados
echo       Widgets >> "%LOGFILE%"

:: Chat/Teams da taskbar (apenas o icone da barra, nao o app)
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarMn /t REG_DWORD /d 0 /f >nul 2>&1
echo       [-] Icone Chat removido da taskbar (app Teams mantido)
echo       Chat taskbar icon >> "%LOGFILE%"

echo       Efeitos visuais desativados!

:: =====================================================
:: ETAPA 7 - LIMPEZA
:: =====================================================
echo.
echo [7/9] Limpando lixo do sistema...
echo. >> "%LOGFILE%"
echo [7/9] Limpeza: >> "%LOGFILE%"

del /s /f /q "%temp%\*" >nul 2>&1
for /d %%p in ("%temp%\*") do rmdir /s /q "%%p" >nul 2>&1
echo       [-] Temporarios do usuario limpos
echo       Temp usuario >> "%LOGFILE%"

del /s /f /q "C:\Windows\Temp\*" >nul 2>&1
for /d %%p in ("C:\Windows\Temp\*") do rmdir /s /q "%%p" >nul 2>&1
echo       [-] Temporarios do Windows limpos
echo       Temp Windows >> "%LOGFILE%"

del /s /f /q "C:\Windows\Prefetch\*" >nul 2>&1
echo       [-] Prefetch limpo
echo       Prefetch >> "%LOGFILE%"

net stop wuauserv >nul 2>&1
:: Aguardar maximo de 3 segundos para servico parar por completo
timeout /t 3 /nobreak >nul 2>&1
del /s /f /q "C:\Windows\SoftwareDistribution\Download\*" >nul 2>&1
for /d %%p in ("C:\Windows\SoftwareDistribution\Download\*") do rmdir /s /q "%%p" >nul 2>&1
net start wuauserv >nul 2>&1
echo       [-] Cache Windows Update limpo
echo       Windows Update cache >> "%LOGFILE%"

del /s /f /q "%LocalAppData%\Microsoft\Windows\Explorer\thumbcache_*.db" >nul 2>&1
echo       [-] Cache de thumbnails limpo
echo       Thumbnails >> "%LOGFILE%"

del /s /f /q "C:\Windows\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\*" >nul 2>&1
echo       [-] Delivery Optimization limpo
echo       DeliveryOptimization >> "%LOGFILE%"

powershell -Command "Clear-RecycleBin -Force -ErrorAction SilentlyContinue" >nul 2>&1
echo       [-] Lixeira esvaziada
echo       Lixeira >> "%LOGFILE%"

echo       Limpeza concluida!

:: =====================================================
:: ETAPA 8 - HIBERNATE
:: =====================================================
echo.
echo [8/9] Desativando Hibernate...
echo. >> "%LOGFILE%"
echo [8/9] Hibernate: >> "%LOGFILE%"

:: NOTA: Em notebooks corporativos, verifique com TI antes.
:: Hibernate pode ser exigido por politica de energia da empresa.
powercfg -h off >nul 2>&1
echo       [-] Hibernate desativado (hiberfil.sys removido)
echo       [!] ATENCAO: Em notebooks, confirme com TI se hibernate e necessario
echo       Hibernate desativado >> "%LOGFILE%"

echo       Hibernate desativado!

:: =====================================================
:: ETAPA 9 - REMOVER BLOATWARE (VERSAO CORPORATIVA)
:: =====================================================
echo.
echo [9/9] Removendo bloatware (versao corporativa)...
echo. >> "%LOGFILE%"
echo [9/9] Bloatware removido: >> "%LOGFILE%"

:: --- MANTIDO: Microsoft Teams (ferramenta corporativa) ---
:: --- MANTIDO: Xbox Identity Provider (pode ser necessario para autenticacao Microsoft) ---

powershell -Command "Get-AppxPackage -Name 'Microsoft.XboxApp' | Remove-AppxPackage" >nul 2>&1
echo       [-] Xbox App
echo       Xbox App >> "%LOGFILE%"

powershell -Command "Get-AppxPackage -Name 'Microsoft.XboxGameOverlay' | Remove-AppxPackage" >nul 2>&1
echo       [-] Xbox Game Overlay
echo       Xbox Game Overlay >> "%LOGFILE%"

powershell -Command "Get-AppxPackage -Name 'Microsoft.XboxGamingOverlay' | Remove-AppxPackage" >nul 2>&1
echo       [-] Xbox Gaming Overlay
echo       Xbox Gaming Overlay >> "%LOGFILE%"

powershell -Command "Get-AppxPackage -Name 'Microsoft.XboxSpeechToTextOverlay' | Remove-AppxPackage" >nul 2>&1
echo       [-] Xbox Speech Overlay
echo       Xbox Speech Overlay >> "%LOGFILE%"

powershell -Command "Get-AppxPackage -Name 'Microsoft.BingWeather' | Remove-AppxPackage" >nul 2>&1
echo       [-] Bing Weather
echo       BingWeather >> "%LOGFILE%"

powershell -Command "Get-AppxPackage -Name 'Microsoft.BingNews' | Remove-AppxPackage" >nul 2>&1
echo       [-] Bing News
echo       BingNews >> "%LOGFILE%"

powershell -Command "Get-AppxPackage -Name 'Microsoft.MicrosoftSolitaireCollection' | Remove-AppxPackage" >nul 2>&1
echo       [-] Solitaire Collection
echo       Solitaire >> "%LOGFILE%"

powershell -Command "Get-AppxPackage -Name 'Microsoft.SkypeApp' | Remove-AppxPackage" >nul 2>&1
echo       [-] Skype (Teams substitui)
echo       Skype >> "%LOGFILE%"

powershell -Command "Get-AppxPackage -Name 'Microsoft.Clipchamp' | Remove-AppxPackage" >nul 2>&1
echo       [-] Clipchamp (editor de video)
echo       Clipchamp >> "%LOGFILE%"

powershell -Command "Get-AppxPackage -Name 'Microsoft.Windows.DevHome' | Remove-AppxPackage" >nul 2>&1
echo       [-] Dev Home
echo       DevHome >> "%LOGFILE%"

powershell -Command "Get-AppxPackage -Name 'Microsoft.Getstarted' | Remove-AppxPackage" >nul 2>&1
echo       [-] Get Started (Tips)
echo       GetStarted >> "%LOGFILE%"

powershell -Command "Get-AppxPackage -Name 'Microsoft.ZuneMusic' | Remove-AppxPackage" >nul 2>&1
echo       [-] Groove Music
echo       ZuneMusic >> "%LOGFILE%"

powershell -Command "Get-AppxPackage -Name 'Microsoft.ZuneVideo' | Remove-AppxPackage" >nul 2>&1
echo       [-] Movies and TV
echo       ZuneVideo >> "%LOGFILE%"

powershell -Command "Get-AppxPackage -Name 'Microsoft.MixedReality.Portal' | Remove-AppxPackage" >nul 2>&1
echo       [-] Mixed Reality Portal
echo       MixedReality >> "%LOGFILE%"

powershell -Command "Get-AppxPackage -Name 'Microsoft.Microsoft3DViewer' | Remove-AppxPackage" >nul 2>&1
echo       [-] 3D Viewer
echo       3DViewer >> "%LOGFILE%"

powershell -Command "Get-AppxPackage -Name 'Microsoft.Advertising.Xaml' | Remove-AppxPackage" >nul 2>&1
echo       [-] Microsoft Advertising
echo       Advertising >> "%LOGFILE%"

powershell -Command "Get-AppxPackage -Name 'king.com.CandyCrushSaga' | Remove-AppxPackage" >nul 2>&1
powershell -Command "Get-AppxPackage -Name 'king.com.CandyCrushSodaSaga' | Remove-AppxPackage" >nul 2>&1
powershell -Command "Get-AppxPackage -Name 'king.com.FarmHeroesSaga' | Remove-AppxPackage" >nul 2>&1
echo       [-] Jogos Candy Crush / King
echo       King Games >> "%LOGFILE%"

echo       [=] Microsoft Teams MANTIDO (ferramenta corporativa)
echo       Teams mantido (corporativo) >> "%LOGFILE%"

echo       Bloatware removido!

:: =====================================================
:: ETAPA 10 - TAREFAS AGENDADAS (REBOOT E LIMPEZA)
:: =====================================================
echo.
echo [10/10] Configurando tarefas agendadas avancadas...
echo. >> "%LOGFILE%"
echo [10/10] Tarefas avancadas (Reboot e Limpeza): >> "%LOGFILE%"

:: Reboot as 2 da manha
schtasks /Create /TN "RebootDiario_Madrugada" /TR "shutdown.exe /r /t 0 /f" /SC DAILY /ST 02:00 /RL HIGHEST /RU "SYSTEM" /F >nul 2>&1
echo       [-] Tarefa de Reboot Diario as 02:00 criada
echo       Reboot Diario >> "%LOGFILE%"

:: Limpeza automatica ao iniciar
:: Limpeza automatica protegida e isolada via SYSTEM
mkdir "C:\ProgramData\ScriptsTI" >nul 2>&1
set "CLEANSCRIPT=C:\ProgramData\ScriptsTI\limpeza_auto.bat"
(
echo @echo off
echo :: Limpeza automatica global ^(Execucao Invisivel via SYSTEM^)
echo del /s /f /q "C:\Windows\Temp\*" ^>nul 2^>^&1
echo for /d %%%%p in ^("C:\Windows\Temp\*"^) do rmdir /s /q "%%%%p" ^>nul 2^>^&1
echo :: Limpeza iterativa da lixeira de p/ cada usuario
echo for /d %%%%u in ^("C:\Users\*"^) do ^(
echo     del /s /f /q "%%%%u\AppData\Local\Temp\*" ^>nul 2^>^&1
echo     for /d %%%%f in ^("%%%%u\AppData\Local\Temp\*"^) do rmdir /s /q "%%%%f" ^>nul 2^>^&1
echo ^)
echo exit /b 0
) > "%CLEANSCRIPT%"
schtasks /Create /TN "LimpezaAutomaticaTemp" /TR "\"%CLEANSCRIPT%\"" /SC ONLOGON /RL HIGHEST /RU "SYSTEM" /F >nul 2>&1
echo       [-] Tarefa de Limpeza de Cache no Logon criada
echo       Limpeza Automatica >> "%LOGFILE%"

echo       Tarefas configuradas!

:: =====================================================
:: RESUMO FINAL
:: =====================================================
echo.
echo =====================================================
echo   OTIMIZACAO CORPORATIVA CONCLUIDA COM SUCESSO!
echo =====================================================
echo.
echo   O que foi feito:
echo     [OK] Servicos desnecessarios desativados
echo     [OK] Tweaks de registro (GPU/CPU/Notificacoes)
echo     [OK] Cortana desativada
echo     [OK] Plano Ultimate/Desempenho Maximo ativado
echo     [OK] Tarefas de telemetria desativadas
echo     [OK] Efeitos visuais desativados
echo     [OK] Sistema limpo (temp/prefetch/update/delivery)
echo     [OK] Hibernate desativado
echo     [OK] Bloatware removido (Teams preservado)
echo     [OK] Tarefas configuradas (Reboot 02:00 e Limpeza Logon)
echo.
echo   Preservado para ambiente corporativo:
echo     [=] Rede TCP/IP intacta   - AnyDesk funcionando
echo     [=] VBS/Memory Integrity  - seguranca ativa
echo     [=] Spectre/Meltdown      - protecao de CPU
echo     [=] RemoteRegistry        - gestao remota de TI
echo     [=] WSearch               - busca do Outlook
echo     [=] WerSvc                - relatorio de erros
echo     [=] Microsoft Teams       - comunicacao corporativa
echo.
echo   IMPORTANTE:
echo     - REINICIE O PC para aplicar todas as mudancas!
echo     - Log salvo em: %LOGFILE%
echo     - Para reverter: rode "reverter_win11.bat"
echo     - Em notebooks: confirme com TI sobre hibernate
echo.
echo =====================================================

echo. >> "%LOGFILE%"
echo ===================================================== >> "%LOGFILE%"
echo  OTIMIZACAO CONCLUIDA: %date% %time% >> "%LOGFILE%"
echo ===================================================== >> "%LOGFILE%"

pause