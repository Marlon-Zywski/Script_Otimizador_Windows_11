@echo off
title   REVERTER OTIMIZACAO WINDOWS 11 - VERSAO CORPORATIVA
color 0C
setlocal EnableDelayedExpansion

:: =====================================================
::  REVERTER OTIMIZACOES - WINDOWS 11 CORPORATIVO
::  Volta os valores alterados para o padrao do Windows
:: =====================================================

:: --- Verificar Administrador ---
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo ============================================
    echo  ERRO: Execute este script como ADMINISTRADOR!
    echo  Clique com botao direito ^> Executar como Administrador
    echo ============================================
    pause
    exit /b 1
)

cls
echo =====================================================
echo   REVERTER OTIMIZACAO WINDOWS 11 - CORPORATIVO
echo =====================================================
echo.
echo   Este script ira DESFAZER as otimizacoes aplicadas,
echo   restaurando os valores padrao do Windows 11.
echo.
echo   MANTIDO INTENCIONALMENTE NESTA REVERSAO:
echo    - Rede, VBS e Spectre (nao foram alterados antes)
echo    - Plano de Energia (Desempenho Maximo preservado)
echo.
echo =====================================================
echo.
set /p CONFIRMA="Deseja prosseguir com a reversao? (S/N): "
if /i not "%CONFIRMA%"=="S" (
    echo Operacao cancelada pelo usuario.
    pause
    exit /b 0
)

echo.
echo [1/5] Reativando servicos...

sc config DiagTrack start=auto >nul 2>&1
sc start DiagTrack >nul 2>&1
reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v AllowTelemetry /f >nul 2>&1
echo       [+] DiagTrack e AllowTelemetry restaurados

sc config DiagnosticDataService start=auto >nul 2>&1
sc start DiagnosticDataService >nul 2>&1
echo       [+] DiagnosticDataService

sc config SysMain start=auto >nul 2>&1
sc start SysMain >nul 2>&1
echo       [+] SysMain (Superfetch)

sc config MapsBroker start=delayed-auto >nul 2>&1
sc start MapsBroker >nul 2>&1
echo       [+] MapsBroker

sc config Fax start=demand >nul 2>&1
echo       [+] Fax

sc config RetailDemo start=demand >nul 2>&1
echo       [+] RetailDemo

sc config WMPNetworkSvc start=demand >nul 2>&1
echo       [+] WMPNetworkSvc

sc config lfsvc start=demand >nul 2>&1
echo       [+] lfsvc (Geolocalizacao)

sc config AJRouter start=demand >nul 2>&1
echo       [+] AJRouter

sc config wisvc start=demand >nul 2>&1
echo       [+] wisvc (Windows Insider)

sc config icssvc start=demand >nul 2>&1
echo       [+] icssvc (Hotspot Movel)

sc config WpcMonSvc start=demand >nul 2>&1
echo       [+] WpcMonSvc (Controle dos Pais)

sc config SEMgrSvc start=demand >nul 2>&1
echo       [+] SEMgrSvc (NFC)

sc config PhoneSvc start=demand >nul 2>&1
echo       [+] PhoneSvc

sc config TrkWks start=auto >nul 2>&1
sc start TrkWks >nul 2>&1
echo       [+] TrkWks

echo.
echo [2/5] Revertendo tweaks de registro...

:: Restaurar Game DVR
reg add "HKCU\System\GameConfigStore" /v GameDVR_Enabled /t REG_DWORD /d 1 /f >nul 2>&1
reg delete "HKCU\System\GameConfigStore" /v GameDVR_FSEBehaviorMode /f >nul 2>&1
reg delete "HKCU\System\GameConfigStore" /v GameDVR_DXGIHonorFSEWindowsCompatible /f >nul 2>&1
reg delete "HKCU\System\GameConfigStore" /v GameDVR_FSEBehavior /f >nul 2>&1
reg delete "HKCU\System\GameConfigStore" /v GameDVR_HonorUserFSEBehaviorMode /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR" /v AllowGameDVR /f >nul 2>&1
echo       [+] Game DVR restaurado

:: Restaurar Notificacoes
reg delete "HKCU\Software\Policies\Microsoft\Windows\Explorer" /v DisableNotificationCenter /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\PushNotifications" /v ToastEnabled /t REG_DWORD /d 1 /f >nul 2>&1
echo       [+] Notificacoes e Central de Acoes restauradas

:: Restaurar apps em segundo plano
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v GlobalUserDisabled /t REG_DWORD /d 0 /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v BackgroundAppGlobalToggle /f >nul 2>&1
echo       [+] Apps em segundo plano restaurados

:: Restaurar Cortana
reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search" /v AllowCortana /f >nul 2>&1
echo       [+] Cortana restaurada

:: Restaurar dicas/ads e Scoobe
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement" /v ScoobeSystemSettingEnabled /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SubscribedContent-338389Enabled /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SubscribedContent-310093Enabled /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SubscribedContent-338388Enabled /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SubscribedContent-338393Enabled /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SoftLandingEnabled /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v RotatingLockScreenEnabled /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v RotatingLockScreenOverlayEnabled /t REG_DWORD /d 1 /f >nul 2>&1
echo       [+] Dicas/sugestoes e tela Scoobe restauradas

:: Restaurar Power Throttling
reg delete "HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" /v PowerThrottlingOff /f >nul 2>&1
echo       [+] Power Throttling restaurado

:: Restaurar Prefetch/Superfetch
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters" /v EnablePrefetcher /t REG_DWORD /d 3 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters" /v EnableSuperfetch /t REG_DWORD /d 3 /f >nul 2>&1
echo       [+] Prefetch/Superfetch restaurados

:: Restaurar prioridade CPU/GPU para padrao
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v SystemResponsiveness /t REG_DWORD /d 20 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v NetworkThrottlingIndex /t REG_DWORD /d 10 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "GPU Priority" /t REG_DWORD /d 8 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v Priority /t REG_DWORD /d 2 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "Scheduling Category" /t REG_SZ /d "Medium" /f >nul 2>&1
echo       [+] Prioridade GPU/CPU restaurada

echo.
echo [3/5] Reativando tarefas agendadas...

schtasks /Delete /TN "RebootDiario_Madrugada" /F >nul 2>&1
schtasks /Delete /TN "LimpezaAutomaticaTemp" /F >nul 2>&1
if exist "%~dp0limpeza_auto.bat" del /f /q "%~dp0limpeza_auto.bat" >nul 2>&1
if exist "C:\ProgramData\ScriptsTI" rmdir /s /q "C:\ProgramData\ScriptsTI" >nul 2>&1
echo       [+] Tarefas customizadas removidas (Reboot e Limpeza)

schtasks /Change /TN "\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser" /Enable >nul 2>&1
echo       [+] Compatibility Appraiser
schtasks /Change /TN "\Microsoft\Windows\Application Experience\ProgramDataUpdater" /Enable >nul 2>&1
echo       [+] ProgramDataUpdater
schtasks /Change /TN "\Microsoft\Windows\Customer Experience Improvement Program\Consolidator" /Enable >nul 2>&1
echo       [+] CEIP Consolidator
schtasks /Change /TN "\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip" /Enable >nul 2>&1
echo       [+] UsbCeip
schtasks /Change /TN "\Microsoft\Windows\Autochk\Proxy" /Enable >nul 2>&1
echo       [+] Autochk Proxy
schtasks /Change /TN "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector" /Enable >nul 2>&1
echo       [+] DiskDiagnosticDataCollector
schtasks /Change /TN "\Microsoft\Windows\Flighting\FeatureConfig\ReconcileFeatures" /Enable >nul 2>&1
echo       [+] ReconcileFeatures
schtasks /Change /TN "\Microsoft\Windows\Flighting\OneSettings\RefreshCache" /Enable >nul 2>&1
echo       [+] RefreshCache

echo.
echo [4/5] Restaurando efeitos visuais...

reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v EnableTransparency /t REG_DWORD /d 1 /f >nul 2>&1
echo       [+] Transparencia ativada
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" /v VisualFXSetting /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Control Panel\Desktop" /v UserPreferencesMask /t REG_BINARY /d 9E3E078012000000 /f >nul 2>&1
reg add "HKCU\Control Panel\Desktop\WindowMetrics" /v MinAnimate /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\Control Panel\Desktop" /v MenuShowDelay /t REG_SZ /d 400 /f >nul 2>&1
echo       [+] Animacoes e sombras restauradas

:: Restaurar Widgets e Chat
reg delete "HKLM\SOFTWARE\Policies\Microsoft\Dsh" /v AllowNewsAndInterests /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarDa /t REG_DWORD /d 1 /f >nul 2>&1
echo       [+] Widgets restaurados
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarMn /t REG_DWORD /d 1 /f >nul 2>&1
echo       [+] Chat restaurado

echo.
echo [5/5] Restaurando Hibernate e Finalizando...

powercfg -h on >nul 2>&1
echo       [+] Hibernate reativado

echo.
echo       [!] NOTA SOBRE APLICATIVOS (Bloatware):
echo           Os apps removidos (Xbox App, Solitaire, etc.) nao podem
echo           ser restaurados via script. Caso precise de algum deles,
echo           basta baixa-lo novamente na Microsoft Store.

echo.
echo =====================================================
echo   REVERSAO CONCLUIDA COM SUCESSO!
echo =====================================================
echo.
echo   REINICIE O PC para que todas as configuracoes
echo   originais voltem a funcionar corretamente.
echo.
echo =====================================================

pause